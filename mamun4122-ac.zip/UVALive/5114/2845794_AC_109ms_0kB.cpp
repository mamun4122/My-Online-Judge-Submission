#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <iterator>
#include <utility>
using namespace std;

#define ALL(p) p.begin(),p.end()
#define mem(p, v) memset(p, v, sizeof(p))
#define READ(f) freopen(f, "r", stdin)
#define WRITE(f) freopen(f, "w", stdout)
#define PB(x) push_back(x)

const double EPS = 1e-9;
const int INF = 0x7f7f7f7f;
int a[20010],b[20010];
int main()
{
    //READ("in.txt");
    //WRITE("out.txt");
    int t;
    scanf("%d",&t);
    int n,k;
    while(t--)
    {
        scanf("%d%d",&n,&k);
        for(int i=0; i<n; i++)
            scanf("%d",&a[i]);
        sort(a,a+n);
        long long res=INF,sum=0;
        for(int i=0;i+k-1<n;i++)
        {
            sum=a[i+k-1]-a[i];
            res=min(sum,res);
        }
        if(k==1)res=0;
        /*if(n>1)
        {
            for(int i=1; i<n; i++)
                b[i]=a[i]-a[i-1];
        }

        for(int i=1;i+k-1<=n;i++)
        {

            sum=b[j];
            for(int j=i,l=1;l<=k-1;l++,j++)
            {
                sum+=b[j];
            }
            res=min(sum,res);
        }
        res=min(sum,res);
        if(k==1||k==0)res=0;*/
        printf("%lld\n",res);
    }


    return 0;
}
