#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <iterator>
#include <utility>
#include <ctime>
using namespace std;


#define mem(p,v) memset(p, v, sizeof(p))
#define SET(p) 	  memset(p, -1, sizeof(p))
#define CLR(p)    memset(p, 0, sizeof(p))


#define    getI(a) 	         scanf("%d", &a)
#define    getII(a,b) 	     scanf("%d%d", &a, &b)
#define    getIII(a,b,c)     scanf("%d%d%d", &a, &b, &c)
#define    getL(n)           scanf("%lld",&n)
#define    getF(n)           scanf("%lf",&n)

#define rep(i,n) for(int i = 1 ; i<=(n) ; i++)
#define repI(i,n) for(int i = 0 ; i<(n) ; i++)
#define    FOREACH(i,t)      for (typeof(t.begin()) i=t.begin(); i!=t.end(); i++)

#define iseq(a,b) (fabs(a-b)<EPS)

#define ALL(p)  p.begin(),p.end()
#define ALLR(p) p.rbegin(),p.rend()
#define READ(f) freopen(f, "r", stdin)
#define WRITE(f) freopen(f, "w", stdout)
#define pb(x) push_back(x)

#define    vi 	 vector < int >
#define    vii 	 vector < vector < int > >
#define    pii 	 pair< int, int >
#define    psi 	 pair< string, int >
#define    ff 	 first
#define    ss 	 second
#define    ll	 long long
#define    ull 	 unsigned long long
#define    ui    unsigned int
#define    ld 	 long double



const double EPS = 1e-9;
const int INF = 0x7f7f7f7f;
const double PI=acos(-1.0);

template< class T > inline T _abs(T n) { return ((n) < 0 ? -(n) : (n)); }
template< class T > inline T _max(T a, T b) { return (!((a)<(b))?(a):(b)); }
template< class T > inline T _min(T a, T b) { return (((a)<(b))?(a):(b)); }
template< class T > inline T gcd(T a, T b) { return (b) == 0 ? (a) : gcd((b), ((a) % (b))); }
template< class T > inline T lcm(T a, T b) { return ((a) / gcd((a), (b)) * (b)); }



//******************DELETE****************
#define mamun
#ifdef mamun
     #define debug(args...) {cerr<<"* ";dbg,args; cerr<<endl;}
#else
    #define debug(args...)  // Just strip off all debug tokens
#endif

struct debugger{
    template<typename T> debugger& operator , (const T& v){
        cerr<<v<<" ";
        return *this;
    }
}dbg;
//******************DELETE****************
int on(int n,int pos)
{
    return (n|(1<<pos));
}

int off(int n,int pos)
{
    return (n-(n & (1<<pos)));
}

bool check(int n,int pos)
{
    return (n & (1<<pos));
}
///start coding from here///
int t,n,m;
#define mx 100001
int arr[mx];

struct nodi{
    int frstmx,scndmx,flag;
    nodi()
    {
        ;
    }
    nodi(int a,int b,int c)
    {
        frstmx=a;
        scndmx=b;
        flag=c;
    }

}tree[mx*3];
nodi maxi(nodi a,nodi b)
{
    nodi temp;
    if(a.frstmx>b.frstmx)
    {
        temp.frstmx=a.frstmx;
        if(a.flag)
        {
            temp.scndmx=b.frstmx;
        }
        else
        {
            temp.scndmx=max(a.scndmx,b.frstmx);
        }
    }
    else
    {
        temp.frstmx=b.frstmx;
        if(b.flag)
        {
            temp.scndmx=a.frstmx;
        }
        else
        {
            temp.scndmx=max(b.scndmx,a.frstmx);
        }
    }
    temp.flag=0;
    return temp;
}
void init(int node,int b,int e)
{
	if(b==e)
	{
		tree[node].frstmx=arr[b];
		tree[node].scndmx=arr[b];
		tree[node].flag=1;
		return;
	}
	int Left=node*2;
	int Right=node*2+1;
	int mid=(b+e)/2;
	init(Left,b,mid);
	init(Right,mid+1,e);
	tree[node]=maxi(tree[Left],tree[Right]);
//	debug(node,tree[node].frstmx,tree[node].scndmx)
}
nodi query(int node,int b,int e,int i,int j)
{
	if (i > e || j < b)return nodi(0,0,0);
	if (b >= i && e <= j) return tree[node];
	int Left=node*2;
	int Right=node*2+1;
	int mid=(b+e)/2;
	nodi p1=query(Left,b,mid,i,j);
	nodi p2=query(Right,mid+1,e,i,j);
	return maxi(p1,p2);
}
void update(int node,int b,int e,int i,int newvalue)
{
	if (i > e || i < b)	return;
	if (b >= i && e <= i) {
		tree[node].frstmx=newvalue;
		tree[node].scndmx=newvalue;
		tree[node].flag=1;
		return;
	}
	int Left=node*2;
	int Right=node*2+1;
	int mid=(b+e)/2;
	update(Left,b,mid,i,newvalue);
	update(Right,mid+1,e,i,newvalue);
	tree[node]=maxi(tree[Left],tree[Right]);
}
int main()
{
	//READ("in.txt");
    //WRITE("out.txt");
	getI(n);
	rep(i,n)getI(arr[i]);
	int q;
	getI(q);
	char x;
	int a,b;
	init(1,1,n);
//	getchar();
	rep(i,q)
	{
	    getchar();
        scanf("%c %d %d",&x,&a,&b);
//            debug(x,a,b)
        if(x=='U')update(1,1,n,a,b);
        else
        {
            nodi tmp=query(1,1,n,a,b);
            printf("%d\n",tmp.frstmx+tmp.scndmx);
        }
	}
	return 0;
}



