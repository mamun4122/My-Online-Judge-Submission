#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
vector<int> v;

int main()
{
      int t;
      scanf("%d",&t);
      while(t--)
      {
            int n,x;
            scanf("%d",&n);
            for(int i=0;i<n;i++)
            {
                  scanf("%d",&x);
                  v.push_back(x);
            }
            sort(v.rbegin(),v.rend());
            int i=2,sum=0;
            while(i<n)
            {
                  sum+=v[i];
                  i+=3;
            }
            printf("%d\n",sum);
            v.clear();
      }



      return 0;
}
