#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <iterator>
#include <utility>
using namespace std;


#define mem(p,v) memset(p, v, sizeof(p))
#define SET(p) 	  memset(p, -1, sizeof(p))
#define CLR(p)    memset(p, 0, sizeof(p))


#define    getI(a) 	         scanf("%d", &a)
#define    getII(a,b) 	     scanf("%d%d", &a, &b)
#define    getIII(a,b,c)     scanf("%d%d%d", &a, &b, &c)
#define    getL(n)           scanf("%lld",&n)
#define    getF(n)           scanf("%lf",&n)

#define    debug(a)     { cout << a <<endl; }
#define    debugI()     { cout << "*" <<endl; }

#define rep(i,n) for( i = 1 ; i<=(n) ; i++)

#define ALL(p)  p.begin(),p.end()
#define ALLR(p) p.rbegin(),p.rend()
#define READ(f) freopen(f, "r", stdin)
#define WRITE(f) freopen(f, "w", stdout)
#define pb(x) push_back(x)

#define    vi 	 vector < int >
#define    vii 	 vector < vector < int > >
#define    pii 	 pair< int, int >
#define    psi 	 pair< string, int >
#define    ff 	 first
#define    ss 	 second
#define    ll	 long long
#define    ull 	 unsigned long long
#define    ui    unsigned int
#define    ld 	 long double


const double EPS = 1e-9;
const int INF = 0x7f7f7f7f;
const double PI=acos(-1.0);

template< class T > inline T _abs(T n) { return ((n) < 0 ? -(n) : (n)); }
template< class T > inline T _max(T a, T b) { return (!((a)<(b))?(a):(b)); }
template< class T > inline T _min(T a, T b) { return (((a)<(b))?(a):(b)); }
template< class T > inline T gcd(T a, T b) { return (b) == 0 ? (a) : gcd((b), ((a) % (b))); }
template< class T > inline T lcm(T a, T b) { return ((a) / gcd((a), (b)) * (b)); }

#define MAXN 120
int pr[MAXN];
map<string,int> m;
struct edge
{
	int u,v,w;
	bool operator < ( const edge& p ) const
	{
		return w < p.w;
	}
};
int flag=0;
vector<edge>e;
int find(int r)
{
   return (pr[r]==r) ? r:  find(pr[r]);
}
int mst(int n)
{
	sort(e.begin(),e.end());
	for(int i=1;i<=n;i++)pr[i]=i;

	int count=0,s=0;
	for(int i=0;i<(int)e.size();i++)
	{
		int u=find(e[i].u);
		int v=find(e[i].v);
		if(u!=v)
		{
			pr[u]=v;
			count++;
			s+=e[i].w;
			//debug(s);
			if(count==n-1){ flag=1;break;}
		}
	}
	return s;
}


char a[55],b[55];
int c;
int main() {
    //READ("in.txt");
    //WRITE("out.txt");
    int n;
    int t;
    getI(t);
    getchar();
    getI(n);
    getchar();
    for(int cs=1;cs<=t;cs++)
    {
        flag=0;
        int cnt=1;
        e.clear();
        m.clear();
        CLR(pr);
        //debug(n);
        for(int j=1;j<=n;j++)
        {
            scanf("%s %s %d", a, b,&c);
//            cin>>a;getchar();
//            cin>>b;getchar();
//            cin>>c;getchar();
//            scanf("%s",&a);getchar();
//            scanf("%s",&b);getchar();
//            scanf("%d",&c);getchar();
           // printf("%s %s %d\n",a,b,c);
            if(m[a]==0)m[a]=cnt++;
            if(m[b]==0)m[b]=cnt++;
            edge get;
            get.u=m[a];get.v=m[b];get.w=c;
            e.push_back(get);
        }
        //debug(cnt);
        getI(n);
        getchar();
        int ans=mst(cnt-1);
        printf("Case %d: ",cs);
        if(!flag)printf("Impossible\n");
        else printf("%d\n",ans);
        //cout<<ans<<endl;


    }
    return 0;
}

