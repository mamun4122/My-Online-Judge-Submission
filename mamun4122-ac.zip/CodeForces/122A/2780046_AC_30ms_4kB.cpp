#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<cstring>
#include<string>
using namespace std;



int main()
{
    int a[]={4,7,44,47,77,74,444,447,477,777,774,744};
    int n,flag=0;
    scanf("%d",&n);
    for(int i=0;i<12;i++)
    {
        if(n%a[i]==0)
        {
            flag=1;
            break;
        }
    }
    if(flag)printf("YES\n");
    else printf("NO\n");

    return 0;
}
